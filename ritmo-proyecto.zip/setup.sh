set -e
npx cap add android
sed -i 's/<activity /<activity android:screenOrientation="portrait" /' android/app/src/main/AndroidManifest.xml
mkdir -p android/app/src/main/java/com/facundo/ritmo
cp MainActivity.java android/app/src/main/java/com/facundo/ritmo/MainActivity.java
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
